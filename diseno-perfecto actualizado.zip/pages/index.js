import { useState } from "react";
import { FaWhatsapp } from "react-icons/fa";

const productos = [
  {
    nombre: "Taza Blanca",
    precio: 60,
    tecnicas: ["Sublimación"],
    descripcion: "La sublimación se realiza con tinta especial y calor, transfiriendo la imagen al recubrimiento de la taza para un acabado duradero."
  },
  {
    nombre: "Taza Mágica",
    precio: 95,
    tecnicas: ["Sublimación"],
    descripcion: "La imagen aparece con el calor del líquido caliente. Técnica de sublimación sobre cerámica termosensible."
  },
  {
    nombre: "Tarro para cerveza",
    precio: 110,
    tecnicas: ["Sublimación", "DTF UV"],
    descripcion: "Sublimación o impresión DTF UV directa sobre el tarro con tintas resistentes."
  },
  {
    nombre: "Playera",
    precio: 199,
    tecnicas: ["Sublimación", "DTF Textil", "Vinil Imprimible"],
    descripcion: "Estampado con sublimación sobre telas claras, DTF para detalles más vivos, o vinil imprimible para diseños complejos."
  },
  {
    nombre: "Sudadera",
    precio: 315,
    tecnicas: ["Sublimación", "DTF Textil", "Vinil Imprimible"],
    descripcion: "Ideal para prendas oscuras o claras. Técnica según tipo de tela y diseño solicitado."
  },
  {
    nombre: "Termo Digital",
    precio: 290,
    tecnicas: ["Sublimación", "DTF UV", "Vinil para Detalle"],
    descripcion: "Personalización con tintas resistentes o vinil para pequeños detalles."
  },
  {
    nombre: "Piedra decorativa corazón",
    precio: 290,
    tecnicas: ["Sublimación"],
    descripcion: "Sublimación sobre superficie tratada de piedra, con acabado artístico."
  },
  {
    nombre: "Vaso Acero Inoxidable Gota",
    precio: 250,
    tecnicas: ["DTF UV", "Sublimación"],
    descripcion: "Personalización duradera y vibrante sobre acero inoxidable."
  },
  {
    nombre: "Gorra",
    precio: 70,
    tecnicas: ["DTF Textil", "Sublimación"],
    descripcion: "Estampado con técnicas adecuadas a la tela y el diseño."
  },
  {
    nombre: "Rompecabezas",
    precio: 120,
    tecnicas: ["Sublimación"],
    descripcion: "Imagen sublimada sobre piezas encajables para regalo creativo."
  },
  {
    nombre: "Placa Acero Inoxidable",
    precio: 200,
    tecnicas: ["Sublimación", "DTF UV"],
    descripcion: "Acabado metálico brillante con impresión directa o sublimación según diseño."
  },
  {
    nombre: "Vasos Cafeteros de Plástico",
    precio: 30,
    tecnicas: ["DTF UV", "Vinil"],
    descripcion: "Decoración con impresión UV directa o vinil resistente."
  }
];

export default function Home() {
  const [seleccionado, setSeleccionado] = useState(productos[0]);
  const [cantidad, setCantidad] = useState(1);
  const [nombre, setNombre] = useState("");
  const [email, setEmail] = useState("");
  const [mensaje, setMensaje] = useState("");

  const precioTotal = seleccionado.precio * cantidad;

  const handleSubmit = (e) => {
    e.preventDefault();
    const numeroWhatsApp = "527205624565";
    const texto = `Hola, me gustaría hacer un pedido:%0A%0ANombre: ${nombre}%0ACorreo: ${email}%0AProducto: ${seleccionado.nombre}%0ACantidad: ${cantidad}%0ATotal: $${precioTotal}%0AMensaje: ${mensaje}`;
    const url = `https://wa.me/${numeroWhatsApp}?text=${texto}`;
    window.open(url, "_blank");
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4 text-center">Calculadora de Precios - Diseño Perfecto</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <select
          onChange={(e) =>
            setSeleccionado(productos.find((p) => p.nombre === e.target.value))
          }
          className="border p-2 rounded w-full"
          value={seleccionado.nombre}
        >
          {productos.map((producto) => (
            <option key={producto.nombre} value={producto.nombre}>
              {producto.nombre}
            </option>
          ))}
        </select>

        <input
          type="number"
          min="1"
          value={cantidad}
          onChange={(e) => setCantidad(Number(e.target.value))}
          className="border p-2 rounded w-full"
          placeholder="Cantidad"
        />
      </div>

      <div className="mt-6 border p-4 rounded shadow">
        <h2 className="text-2xl font-semibold">{seleccionado.nombre}</h2>
        <p className="text-gray-600">Precio unitario: <strong>${seleccionado.precio}</strong></p>
        <p className="text-gray-800">Técnicas disponibles: {seleccionado.tecnicas.join(", ")}</p>
        <p className="text-gray-700 mt-2">{seleccionado.descripcion}</p>
        <p className="text-xl font-bold text-green-700 mt-4">Precio total: ${precioTotal}</p>
      </div>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4 bg-white p-6 rounded shadow">
        <h3 className="text-xl font-semibold">Formulario de Pedido</h3>

        <input
          type="text"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
          className="border p-2 rounded w-full"
          placeholder="Tu nombre"
          required
        />

        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="border p-2 rounded w-full"
          placeholder="Tu correo electrónico"
          required
        />

        <textarea
          value={mensaje}
          onChange={(e) => setMensaje(e.target.value)}
          className="border p-2 rounded w-full"
          placeholder="Mensaje adicional (opcional)"
          rows="4"
        ></textarea>

        <button type="submit" className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded">
          <FaWhatsapp className="text-lg" /> Enviar Pedido por WhatsApp
        </button>
      </form>
    </div>
  );
}
